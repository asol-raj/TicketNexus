const express = require("express");
const expressLayouts = require("express-ejs-layouts");
const cors = require('cors');
const cookieParser = require("cookie-parser");

const ejs = require('ejs');
const path = require("path");

const app = express();
ejs.delimiter = '?';

// ========== Middleware ==========

app.use(cors());
app.use(express.urlencoded({ extended: true })); // for form data
app.use(express.json()); // for JSON requests
app.use(cookieParser());

// Static files (CSS, JS, images)
app.use(express.static(path.join(__dirname, "src", "public")));

// ========== View Engine ==========
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "src", "views"));
app.use(expressLayouts);
app.set("layout", "layouts/layout"); // default layout

app.use('/', require('./src/router/routes'));

// ========== Server ==========
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
