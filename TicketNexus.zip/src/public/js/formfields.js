export default {
    test: {
        name: { label: 'Test', type: 'text '}
    }
}