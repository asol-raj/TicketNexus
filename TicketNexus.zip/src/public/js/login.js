import { jq, log } from './help.js';

document.addEventListener('DOMContentLoaded', () => {
    log('ok');

    jq('#loginForm').on('submit', function(e){
        e.preventDefault();
        
    })
})