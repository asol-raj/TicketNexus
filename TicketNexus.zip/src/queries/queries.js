const Queries = {
    test: 'Select 1',

}

module.exports = Queries;